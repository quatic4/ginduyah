#!/usr/bin/env bash
set -euo pipefail

ginduyah_bundle=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
ginduyah_root=$(git rev-parse --show-toplevel)
cd "$ginduyah_root"
case "$(git remote get-url origin)" in
  https://github.com/quatic4/ginduyah|https://github.com/quatic4/ginduyah.git|git@github.com:quatic4/ginduyah.git) ;;
  *) printf '%s\n' 'Run this inside your quatic4/ginduyah Codespace.' >&2; exit 1 ;;
esac
if ! git diff --quiet || ! git diff --cached --quiet; then
  printf '%s\n' 'Commit or stash your current tracked changes before applying this update.' >&2
  exit 1
fi
git switch team-studio
git pull --ff-only origin team-studio
if git apply --reverse --check "$ginduyah_bundle/no-login.patch" 2>/dev/null; then
  printf '%s\n' 'The no-login update is already applied. Retrying the push.'
else
  git apply --check "$ginduyah_bundle/no-login.patch"
  git apply --index "$ginduyah_bundle/no-login.patch"
  git diff --cached --check
  git commit -m "Make team studio shared without accounts"
fi
git push -u origin team-studio
printf '%s\n' 'Uploaded to team-studio. Vercel will build the preview. Shared saves still need the Supabase SQL and environment variables in START_HERE.txt.'
