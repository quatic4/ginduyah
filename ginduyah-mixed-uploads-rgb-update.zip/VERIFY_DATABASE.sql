do $$
begin
  if to_regprocedure('shared_studio.next_screenshot_slot(uuid,text,date,timestamptz)') is null then
    raise exception 'The mixed-upload migration did not finish.';
  end if;
  if has_function_privilege('anon','public.studio_files(text,uuid,text,jsonb)','execute') then
    raise exception 'Screenshot access must stay restricted to the upload service.';
  end if;
end;
$$;
select 'Mixed upload database ready; private screenshot access preserved.' as result;
