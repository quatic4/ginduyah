#!/usr/bin/env bash
set -euo pipefail
package_dir=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
repo_dir=$(git rev-parse --show-toplevel 2>/dev/null) || { echo 'Open the ginduyah Codespace, then run this command from its terminal.'; exit 1; }
cd "$repo_dir"
remote_url=$(git remote get-url origin)
if [[ ! "$remote_url" =~ github\.com[:/]quatic4/ginduyah(\.git)?$ ]]; then
  echo 'Stopped: this is not the quatic4/ginduyah repository.'; exit 1
fi
if [[ -n "$(git status --porcelain --untracked-files=no)" ]]; then
  echo 'Stopped: commit or stash your existing tracked changes, then run again.'; exit 1
fi
command -v pnpm >/dev/null || { echo 'pnpm is missing. Run: corepack enable'; exit 1; }
git fetch origin main
branch="mixed-uploads-theme-$(date -u +%Y%m%d%H%M%S)-${RANDOM}"
git switch -c "$branch" origin/main
if git apply --reverse --check "$package_dir/update.patch" 2>/dev/null; then
  echo 'The website code is already applied; checking the cloud setup.'
else
  if ! git apply --3way --index "$package_dir/update.patch"; then
    echo 'Stopped: another change overlaps this update. Nothing was pushed. Send the output so the conflict can be resolved.'; exit 1
  fi
  pnpm install --frozen-lockfile
  pnpm lint
  pnpm test
  pnpm build
  git commit -m 'Add mixed comic/post uploads and site-wide RGB themes'
fi
supabase_cli=(npx --yes supabase@2.120.0)
project_ref='meyibdsksuhbaeygvpob'
if ! "${supabase_cli[@]}" db query --project-ref "$project_ref" 'select 1 as connected' >/dev/null 2>&1; then
  echo 'Sign in to Supabase when prompted. Use the account that owns ginduyah-studio.'
  "${supabase_cli[@]}" login
fi
# Apply just this additive migration, leaving existing migration history alone.
"${supabase_cli[@]}" db query --project-ref "$project_ref" --file "$package_dir/APPLY_DATABASE.sql"
# This function already uses the team PIN session instead of Supabase Auth JWTs.
"${supabase_cli[@]}" functions deploy studio-files --project-ref "$project_ref" --use-api --no-verify-jwt
"${supabase_cli[@]}" db query --project-ref "$project_ref" --file "$package_dir/VERIFY_DATABASE.sql"
# Non-forced push: if main advanced during setup, stop rather than replace it.
git push -u origin HEAD:main
echo 'Uploaded to main. Wait for Vercel to finish, then refresh ginduyah.vercel.app.'
echo 'Theme is in the header on every page. Team Studio batches now have a Type selector per file.'
