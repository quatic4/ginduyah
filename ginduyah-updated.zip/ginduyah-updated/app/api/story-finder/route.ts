import { NextRequest, NextResponse } from "next/server";
export const runtime = "edge";

type RedditPost = { id?:string; title?:string; selftext?:string; author?:string; subreddit?:string; score?:number; num_comments?:number; upvote_ratio?:number; created_utc?:number; permalink?:string; over_18?:boolean; stickied?:boolean };

function virality(post: RedditPost) {
  const score = Math.max(0, Number(post.score || 0));
  const comments = Math.max(0, Number(post.num_comments || 0));
  const ratio = Math.max(0, Math.min(1, Number(post.upvote_ratio || 0)));
  const ageHours = Math.max(.25, (Date.now()/1000 - Number(post.created_utc || 0)) / 3600);
  const velocity = (score + comments * 3) / Math.pow(ageHours + 2, .72);
  const engagement = comments / Math.max(1, score);
  const title = String(post.title || "");
  const body = String(post.selftext || "");
  const hook = /\?|aita|am i|wife|husband|boyfriend|girlfriend|cheat|caught|secret|confess|family|wedding|friend|boss|coworker|roommate|ex\b|money|lied|refuse|wrong/i.test(`${title} ${body}`) ? 8 : 0;
  const debate = engagement > .08 ? 8 : engagement > .04 ? 5 : engagement > .02 ? 3 : 0;
  const raw = 22 + Math.log10(score + 1) * 10 + Math.log10(comments + 1) * 9 + Math.log10(velocity + 1) * 9 + ratio * 7 + hook + debate;
  return Math.max(1, Math.min(100, Math.round(raw)));
}

export async function GET(request: NextRequest) {
  const sub = (request.nextUrl.searchParams.get("subreddits") || "AmItheAsshole,TrueOffMyChest,confessions,relationship_advice,tifu").split(",").map(s=>s.trim().replace(/^r\//,"" )).filter(Boolean).slice(0,8);
  const maxChars = Math.max(100, Math.min(5000, Number(request.nextUrl.searchParams.get("maxChars") || 700)));
  try {
    const batches = await Promise.all(sub.map(async subreddit => {
      const url = `https://www.reddit.com/r/${encodeURIComponent(subreddit)}/hot.json?limit=50&raw_json=1`;
      const response = await fetch(url, { headers: { "User-Agent": "GinduyahStoryFinder/1.0", Accept: "application/json" }, cache: "no-store" });
      if (!response.ok) return [] as RedditPost[];
      const json = await response.json() as { data?: { children?: Array<{data?:RedditPost}> } };
      return (json.data?.children || []).map(x=>x.data).filter((x): x is RedditPost => Boolean(x));
    }));
    const posts = batches.flat().filter(p => !p.stickied && !p.over_18).map(p => {
      const title = String(p.title || ""); const body = String(p.selftext || ""); const characters = `${title}${body ? " " + body : ""}`.length;
      return { id:p.id || p.permalink, title, body, author:p.author || "anonymous", subreddit:p.subreddit || "reddit", score:Number(p.score||0), comments:Number(p.num_comments||0), upvoteRatio:Number(p.upvote_ratio||0), characters, virality:virality(p), url:`https://www.reddit.com${p.permalink || ""}` };
    }).filter(p=>p.body && p.characters <= maxChars && p.characters >= 120).sort((a,b)=>b.virality-a.virality || b.comments-a.comments).slice(0,40);
    return NextResponse.json({ posts, searched:sub, maxChars });
  } catch (error) {
    return NextResponse.json({ error:error instanceof Error ? error.message : "Unable to fetch Reddit stories" }, { status:502 });
  }
}
