import type { Metadata } from "next";
import { Analytics } from "@vercel/analytics/next";
import { SpeedInsights } from "@vercel/speed-insights/next";
import Link from "next/link";
import "./globals.css";

export const metadata: Metadata = {
  metadataBase: new URL("https://ginduyah.vercel.app"),
  title: "Ginduyah — Reddit Tools for Shorts",
  description: "Find high-potential Reddit stories, score their virality, and turn them into short-form story cards."
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>
    <header className="site-header">
      <Link className="brand" href="/"><span className="brand-dot">G</span><span>ginduyah</span><b className="beta">BETA</b></Link>
      <nav className="nav-tabs">
        <Link href="/">Home</Link>
        <Link href="/generator">Card Generator <span>BETA</span></Link>
        <Link href="/story-finder">Story Finder <span>BETA</span></Link>
      </nav>
    </header>
    {children}
    <footer className="site-footer"><strong>Ginduyah</strong><span>Built for short-form storytellers. Reddit content belongs to its original authors.</span></footer>
    <Analytics /><SpeedInsights />
  </body></html>;
}
