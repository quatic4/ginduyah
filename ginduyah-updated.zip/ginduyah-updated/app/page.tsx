import Link from "next/link";

export default function Home() {
  return <main className="home-page">
    <section className="hero">
      <p className="eyebrow">REDDIT → SHORT-FORM READY <span className="beta">BETA</span></p>
      <h1>Find better stories.<br/><em>Post better Shorts.</em></h1>
      <p className="hero-copy">Ginduyah gives Reddit-story creators one place to discover posts, judge their viral potential, and turn them into clean story cards.</p>
      <div className="hero-actions">
        <Link className="primary-btn" href="/story-finder">Find viral stories →</Link>
        <Link className="secondary-btn" href="/generator">Open card generator</Link>
      </div>
    </section>
    <section className="tool-grid">
      <Link className="tool-card featured" href="/story-finder">
        <div className="tool-top"><span className="tool-icon">↗</span><span className="beta">BETA</span></div>
        <h2>Reddit Story Finder</h2>
        <p>Search hot posts from high-engagement story subreddits, filter by character count, and rank each result with a virality score.</p>
        <span className="tool-link">Open Story Finder →</span>
      </Link>
      <Link className="tool-card" href="/generator">
        <div className="tool-top"><span className="tool-icon">▣</span><span className="beta">BETA</span></div>
        <h2>Story Card Generator</h2>
        <p>Paste a Reddit link or edit a story manually, preview it as a vertical card, and export a PNG for Shorts, TikTok, or Reels.</p>
        <span className="tool-link">Open Generator →</span>
      </Link>
    </section>
    <section className="how"><p className="eyebrow">BUILT AROUND YOUR WORKFLOW</p><h2>From Reddit post to upload-ready.</h2><div className="steps"><article><b>01</b><h3>Find</h3><p>Pull fresh stories from the subreddits that consistently create debate, shock, and comments.</p></article><article><b>02</b><h3>Score</h3><p>Use the 1–100 virality score to quickly spot posts with strong engagement and hook potential.</p></article><article><b>03</b><h3>Create</h3><p>Turn the winning story into a clean visual card and move it straight into your Shorts workflow.</p></article></div></section>
  </main>;
}
