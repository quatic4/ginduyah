"use client";
import { useEffect, useMemo, useState } from "react";

type Post = { id:string; title:string; body:string; author:string; subreddit:string; score:number; comments:number; upvoteRatio:number; characters:number; virality:number; url:string };
const defaults = ["AmItheAsshole","TrueOffMyChest","confessions","relationship_advice","tifu"];
function scoreClass(score:number){ return score >= 85 ? "elite" : score >= 70 ? "strong" : score >= 55 ? "good" : "average"; }
function scoreLabel(score:number){ return score >= 85 ? "HARD HITTER" : score >= 70 ? "STRONG" : score >= 55 ? "GOOD" : "AVERAGE"; }
export default function StoryFinder(){
  const [maxChars,setMaxChars]=useState(700); const [subreddits,setSubreddits]=useState(defaults.join(", ")); const [posts,setPosts]=useState<Post[]>([]); const [loading,setLoading]=useState(false); const [error,setError]=useState(""); const [minScore,setMinScore]=useState(0);
  async function search(){ setLoading(true); setError(""); try{ const params=new URLSearchParams({maxChars:String(maxChars),subreddits}); const r=await fetch(`/api/story-finder?${params}`); const data=await r.json(); if(!r.ok) throw new Error(data.error||"Search failed"); setPosts(data.posts||[]);}catch(e){setError(e instanceof Error?e.message:"Search failed");}finally{setLoading(false);} }
  useEffect(()=>{search();},[]);
  const shown=useMemo(()=>posts.filter(p=>p.virality>=minScore),[posts,minScore]);
  return <main className="finder-page">
    <section className="page-title"><p className="eyebrow">REDDIT STORY FINDER <span className="beta">BETA</span></p><h1>Find stories worth <em>posting.</em></h1><p>Fresh Reddit stories ranked for short-form potential. The score is a heuristic based on engagement, velocity, comment activity, title hooks, and post length — not a guarantee of views.</p></section>
    <section className="finder-controls">
      <label>Subreddits<input value={subreddits} onChange={e=>setSubreddits(e.target.value)} placeholder="AmItheAsshole, TrueOffMyChest..."/></label>
      <label>Max characters<select value={maxChars} onChange={e=>setMaxChars(Number(e.target.value))}><option value="350">350 — very short</option><option value="500">500 — short</option><option value="700">700 — Shorts sweet spot</option><option value="1000">1,000 — medium</option><option value="1500">1,500 — longer</option></select></label>
      <label>Minimum virality<select value={minScore} onChange={e=>setMinScore(Number(e.target.value))}><option value="0">Show all</option><option value="55">55+ Good</option><option value="70">70+ Strong</option><option value="85">85+ Hard hitters</option></select></label>
      <button className="primary-btn search-btn" onClick={search} disabled={loading}>{loading?"Searching Reddit…":"Find stories"}</button>
    </section>
    {error && <div className="error-box">{error}</div>}
    <div className="finder-summary"><strong>{loading?"Searching…":`${shown.length} stories found`}</strong><span>Ranked highest virality first</span></div>
    <section className="results-grid">{shown.map(post=><article className="story-result" key={post.id}>
      <div className="result-head"><div><span className="subreddit">r/{post.subreddit}</span><small>{post.characters} chars · {post.score.toLocaleString()} pts · {post.comments.toLocaleString()} comments</small></div><div className={`score ${scoreClass(post.virality)}`}><strong>{post.virality}</strong><span>{scoreLabel(post.virality)}</span></div></div>
      <h2>{post.title}</h2><p>{post.body}</p>
      <div className="result-actions"><a href={post.url} target="_blank" rel="noreferrer">View Reddit ↗</a><button onClick={()=>navigator.clipboard?.writeText(`${post.title}\n\n${post.body}`)}>Copy story</button></div>
    </article>)}</section>
    {!loading && !shown.length && <div className="empty-state"><h2>No stories matched.</h2><p>Raise the character limit, lower the minimum score, or try different subreddits.</p></div>}
  </main>;
}
