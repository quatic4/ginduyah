# Ginduyah v0.2

Multi-tool Reddit creator site with:
- Homepage
- Reddit Story Finder with 1–100 virality scoring
- Character-count filtering
- Reddit Story Card Generator
- BETA badges throughout

## Run
pnpm install
pnpm dev

## Deploy
npx vercel --prod
