#!/usr/bin/env bash
set -euo pipefail

update_dir=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
patch_file="$update_dir/ginduyah-pin-channels.patch"
repo_root=$(git rev-parse --show-toplevel 2>/dev/null) || { printf '%s\n' 'Open the ginduyah repository terminal, then run this again.'; exit 1; }
cd "$repo_root"
remote_url=$(git config --get remote.origin.url)
case "$remote_url" in
  https://github.com/quatic4/ginduyah|https://github.com/quatic4/ginduyah.git|git@github.com:quatic4/ginduyah.git|ssh://git@github.com/quatic4/ginduyah.git) ;;
  *) printf '%s\n' 'Stopped: this is not the quatic4/ginduyah repository.'; exit 1 ;;
esac
if ! git diff --quiet || ! git diff --cached --quiet; then
  printf '%s\n' 'Stopped: commit or stash your existing tracked-file changes first.'
  exit 1
fi

git fetch origin main team-studio
update_branch="studio-pin-$(date -u +%Y%m%d%H%M%S)-$$"
git switch -c "$update_branch" origin/main
if ! git cat-file -e HEAD:supabase/migrations/20260917214744_shared_studio_without_accounts.sql 2>/dev/null; then
  git merge --ff-only origin/team-studio
fi

if git apply --reverse --check "$patch_file" >/dev/null 2>&1; then
  printf '%s\n' 'This update is already applied.'
else
  git apply --check --index "$patch_file"
  git apply --index "$patch_file"
  git diff --cached --check
  git commit -m "Feature two channels and protect team studio with a shared PIN"
fi

git push origin HEAD:main
printf '%s\n' 'Uploaded to main. Wait for Vercel to finish the deployment.' 'Then open ginduyah.vercel.app/studio and enter your team PIN to activate protection.' 'Your shared board data remains saved; no new environment variables or SQL are needed.'
