#!/usr/bin/env bash
set -euo pipefail
update_dir=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
patch_file="$update_dir/ginduyah-calendar-mobile.patch"
repo_root=$(git rev-parse --show-toplevel 2>/dev/null) || { printf '%s\n' 'Open the ginduyah repository terminal, then run this again.'; exit 1; }
cd "$repo_root"
remote_url=$(git config --get remote.origin.url)
case "$remote_url" in
  https://github.com/quatic4/ginduyah|https://github.com/quatic4/ginduyah.git|git@github.com:quatic4/ginduyah.git|ssh://git@github.com/quatic4/ginduyah.git) ;;
  *) printf '%s\n' 'Stopped: this is not the quatic4/ginduyah repository.'; exit 1 ;;
esac
if ! git diff --quiet || ! git diff --cached --quiet; then
  printf '%s\n' 'Stopped: commit or stash your existing tracked-file changes first.'
  exit 1
fi
git fetch origin main
update_branch="calendar-mobile-$(date -u +%Y%m%d%H%M%S)-$$"
git switch -c "$update_branch" origin/main
if git apply --reverse --check "$patch_file" >/dev/null 2>&1; then
  printf '%s\n' 'This update is already applied.'
else
  git apply --check --index "$patch_file"
  git apply --index "$patch_file"
  git diff --cached --check
  git commit -m "Add upload calendar, days-ahead coverage and mobile Reddit import"
fi
git push origin HEAD:main
printf '%s\n' 'Uploaded to main. Wait for Vercel to finish deploying.' 'Open https://ginduyah.vercel.app/studio and enter your existing team PIN.' 'Calendar database setup is already complete. Existing submissions are preserved.' 'Automatic Reddit import still needs approved Reddit API credentials in Vercel. See docs/calendar-and-reddit.md.'
